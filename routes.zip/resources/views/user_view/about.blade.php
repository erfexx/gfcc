<div class="site-section cta-big-image" id="about-section">
    <div class="container">

        <img src="{{asset('user_view/images/bg.jpg')}}" alt="Image" class="img-fluid">
        <div class="img-box">
{{--            <span class="sub-title">Creative Skills</span>--}}
            <h2>What is GFC?</h2>
            <p>
                GFC is Lorem ipsum dolor sit amet, consectetur adipisicing elit. At cupiditate earum eligendi facere, hic, ipsa natus nostrum odio possimus quod rem sequi temporibus ullam, ut vel veritatis voluptas voluptatem. Quibusdam.
            </p>
{{--            <p><a href="#" class="btn btn-outline-dark">Read More</a></p>--}}
        </div>
    </div>
</div>