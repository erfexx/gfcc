<section class="site-section" id="services-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-12">
                <h2 class="section-title mb-3">Our Services</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <div class=" box-with-humber">
                    <h2 class="text-black"><span class="text-primary">01.</span>GFC Sport</h2>
                    <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Et praesentium eos nulla qui commodi consectetur beatae fugiat. Veniam iste rerum perferendis.</p>

                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class=" box-with-humber">
                    <h2 class="text-black"><span class="text-primary">02.</span>Pray Service</h2>
                    <p class="mb-4">Every Friday at 7pm on GPdI Greenvile Church.</p>

                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class=" box-with-humber">
                    <h2 class="text-black"><span class="text-primary">03.</span>Youth Service</h2>
                    <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Et praesentium eos nulla qui commodi consectetur beatae fugiat. Veniam iste rerum perferendis.</p>

                </div>
            </div>
        </div>
    </div>
</section>