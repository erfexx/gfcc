<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900" rel="stylesheet">

<link rel="stylesheet" href="{{asset('user_view/fonts/icomoon/style.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/jquery-ui.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/owl.theme.default.min.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/owl.theme.default.min.css')}}">

<link rel="stylesheet" href="{{asset('user_view/css/jquery.fancybox.min.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/bootstrap-datepicker.css')}}">
<link rel="stylesheet" href="{{asset('user_view/fonts/flaticon/font/flaticon.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/aos.css')}}">
<link rel="stylesheet" href="{{asset('user_view/css/style.css')}}">