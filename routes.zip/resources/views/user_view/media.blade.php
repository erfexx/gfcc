<section class="site-section" id="media-section">
    <div class="container">

        <div class="row">
            <div class="col-lg-6">
                <script src="https://apps.elfsight.com/p/platform.js" defer></script>
                <div class="elfsight-app-dd0ef10d-535f-41e2-bf14-fad2705dd5ed"></div>

                {{--<div class="owl-carousel slide-one-item-alt">
                    <img src="{{asset('user_view/images/slide_1.jpg')}}" alt="Image" class="img-fluid">
                    <img src="{{asset('user_view/images/slide_1.jpg')}}" alt="Image" class="img-fluid">
                    <img src="{{asset('user_view/images/slide_2.jpg')}}" alt="Image" class="img-fluid">
                    <img src="{{asset('user_view/images/slide_3.jpg')}}" alt="Image" class="img-fluid">
                    <img src="{{asset('user_view/images/slide_4.jpg')}}" alt="Image" class="img-fluid">
                </div>
                <div class="custom-direction">
                    <a href="#" class="custom-prev">Prev</a><a href="#" class="custom-next">Next</a>
                </div>--}}

                {{--<div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
                </div>--}}

            </div>
            <div class="col-lg-5 ml-auto">

                <h2 class="section-title mb-3">Follow us on our Instagram</h2>
                <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                <p>Est qui eos quasi ratione nostrum excepturi id recusandae fugit omnis ullam pariatur itaque nisi voluptas impedit  Quo suscipit omnis iste velit maxime.</p>

{{--                <p><a href="#" class="btn btn-primary mr-2 mb-2">Learn More</a></p>--}}

            </div>
        </div>
        <br>
        <br>
        <div class="row">

            <div class="col-lg-5 ml-auto">

                <h2 class="section-title mb-3">Add Our Official Line</h2>
                <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                <p>Est qui eos quasi ratione nostrum excepturi id recusandae fugit omnis ullam pariatur itaque nisi voluptas impedit  Quo suscipit omnis iste velit maxime.</p>

{{--                <p><a href="#" class="btn btn-primary mr-2 mb-2">Learn More</a></p>--}}

            </div>



            <div class="col-lg-6">
                <div class="col-md-10" style="height: auto;">
                    <video style="width: 100%; height: 60%;" src="{{asset('user_view/images/finale.mp4')}}" autoplay loop></video>
                </div>
            </div>
        </div>
        <br>
        <br>
        <div class="row">

            <div class="col-lg-6">
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/9aFVHcKLgDw" allowfullscreen></iframe>
                </div>
            </div>

            <div class="col-lg-5 ml-auto">

                <h2 class="section-title mb-3">Watch Our Latest Videos</h2>
                <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                <p>Est qui eos quasi ratione nostrum excepturi id recusandae fugit omnis ullam pariatur itaque nisi voluptas impedit  Quo suscipit omnis iste velit maxime.</p>

{{--                <p><a href="#" class="btn btn-primary mr-2 mb-2">Learn More</a></p>--}}

            </div>


        </div>
    </div>
</section>